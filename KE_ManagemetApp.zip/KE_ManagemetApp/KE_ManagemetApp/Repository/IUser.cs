﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KE_ManagemetApp.Model;


namespace KE_ManagemetApp.Repository
{
    public interface IUser
    {
        List<User> GetUsers();
        Task<List<User>> AddUserAsync(List<User> user);
        User UserUpdateAsync(User user);
        List<User> GetUserById(int UserId);
        List<User> DeleteById(int UserId);
    }
}
