﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KE_ManagemetApp.Model;

namespace KE_ManagemetApp.Repository
{
    public interface IEquipment
    {
        List<Equipment> GetAllEquipment();
        Task<List<Equipment>> AddEquipmentAsync(List<Equipment> equip, int Id);
        Equipment UpdateEquipment(Equipment equip, int Id);
        List<Equipment> GetEquipmentById(int Id);
        List<Equipment> DeleteEquipmentById(int EquipId);
    }
}
