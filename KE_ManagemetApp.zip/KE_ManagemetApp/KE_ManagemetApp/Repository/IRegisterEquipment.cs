﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KE_ManagemetApp.Model;

namespace KE_ManagemetApp.Repository
{
    public interface IRegisterEquipment
    {
        List<RegisteredEquipment> GetAllRegisteredEquipment();
        Task<List<RegisteredEquipment>> AddRegisteredEquipmentAsync(List<RegisteredEquipment> registeredEquipment);
        RegisteredEquipment UpdateRegisteredEquipment(RegisteredEquipment registeredEquipment, int Id);
        List<RegisteredEquipment> GetRegisteredEquipmentById(int Id);
        List<RegisteredEquipment> DeleteRegisteredEquipmentById(int Id);
    }
}
