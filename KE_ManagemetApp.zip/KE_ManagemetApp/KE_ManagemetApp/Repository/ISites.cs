﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KE_ManagemetApp.Model;

namespace KE_ManagemetApp.Repository
{
    public interface ISites
    {
        List<Site> GetAllSites();
        Task<List<Site>> AddSiteAsync(List<Site> site);
        Site UpdateSite(Site site, int Id);
        List<Site> GetSiteById(int Id);
        List<Site> DeleteSiteById(int SiteId);
    }
}
