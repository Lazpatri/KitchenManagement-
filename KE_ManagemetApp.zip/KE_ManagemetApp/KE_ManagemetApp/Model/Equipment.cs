﻿using System;
using System.Collections.Generic;

namespace KE_ManagemetApp.Model
{
    public partial class Equipment
    {
        public int EquipmentId { get; set; }
        public string? SerialNumber { get; set; }
        public string? Description { get; set; }
        public string? Condition { get; set; }
        public int? UserId { get; set; }
    }
}
