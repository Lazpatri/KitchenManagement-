﻿using System;
using System.Collections.Generic;

namespace KE_ManagemetApp.Model
{
    public partial class RegisteredEquipment
    {
        public int Id { get; set; }
        public int? EquipmentId { get; set; }
        public int? SiteId { get; set; }
    }
}
