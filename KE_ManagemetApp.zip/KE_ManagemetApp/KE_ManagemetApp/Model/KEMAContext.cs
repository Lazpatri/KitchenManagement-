﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace KE_ManagemetApp.Model
{
    public partial class KEMAContext : DbContext
    {
        public KEMAContext()
        {
        }

        public KEMAContext(DbContextOptions<KEMAContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Equipment> Equipment { get; set; } = null!;
        public virtual DbSet<RegisteredEquipment> RegisteredEquipments { get; set; } = null!;
        public virtual DbSet<Site> Sites { get; set; } = null!;
        public virtual DbSet<User> Users { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=KEMA;Trusted_Connection=true;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Equipment>(entity =>
            {
                entity.Property(e => e.EquipmentId).HasColumnName("EquipmentId");

                entity.Property(e => e.Condition).HasColumnName("Condition");

                entity.Property(e => e.Description).HasColumnName("Description");

                entity.Property(e => e.SerialNumber).HasColumnName("SerialNumber");

                entity.Property(e => e.UserId).HasColumnName("UserId");
            });

            modelBuilder.Entity<RegisteredEquipment>(entity =>
            {
                entity.ToTable("Registered_equipment");

                entity.Property(e => e.EquipmentId).HasColumnName("equipment_id");

                entity.Property(e => e.SiteId).HasColumnName("site_id");
            });

            modelBuilder.Entity<Site>(entity =>
            {
                entity.ToTable("Site");

                entity.Property(e => e.SiteId).HasColumnName("site_id");

                entity.Property(e => e.Active).HasColumnName("active");

                entity.Property(e => e.Description).HasColumnName("description");

                entity.Property(e => e.UserId).HasColumnName("user_id");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("User");

                entity.Property(e => e.UserId).HasColumnName("user_id").ValueGeneratedOnAdd().UseIdentityColumn(1,1);

                entity.Property(e => e.EmailAddress).HasColumnName("email_address");

                entity.Property(e => e.FirstName).HasColumnName("first_name");

                entity.Property(e => e.LastName).HasColumnName("last_name");

                entity.Property(e => e.Password).HasColumnName("password");

                entity.Property(e => e.UserName).HasColumnName("user_name");

                entity.Property(e => e.UserType).HasColumnName("user_type");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
