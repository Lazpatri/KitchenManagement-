﻿using System;
using System.Collections.Generic;

namespace KE_ManagemetApp.Model
{
    public partial class Site
    {
        public int SiteId { get; set; }
        public int? UserId { get; set; }
        public string? Description { get; set; }
        public bool? Active { get; set; }
    }
}
