﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KE_ManagemetApp.Model;
using KE_ManagemetApp.Repository;

namespace KE_ManagemetApp.Controllers
{
    public class RegisterEquipmentController : IRegisterEquipment
    {
        private readonly KEMAContext _context;
        public RegisterEquipmentController(KEMAContext ctx)
        {
            _context = ctx;
        }
        public async Task<List<RegisteredEquipment>> AddRegisteredEquipmentAsync(List<RegisteredEquipment> registeredEquipment)
        {
            _context.RegisteredEquipments.AddRange(registeredEquipment);
            await _context.SaveChangesAsync();
            return registeredEquipment;
        }

        public List<RegisteredEquipment> DeleteRegisteredEquipmentById(int SiteId)
        {
            List<RegisteredEquipment> regequip = _context.RegisteredEquipments.Where(x => x.SiteId == SiteId).ToList();

            _context.RegisteredEquipments.RemoveRange(regequip);
            _context.SaveChanges();
            return regequip;
        }

        public List<RegisteredEquipment> GetAllRegisteredEquipment()
        {
            List<RegisteredEquipment> eq = new List<RegisteredEquipment>();
            eq = _context.RegisteredEquipments.ToList();
            return eq;
        }

        public List<RegisteredEquipment> GetRegisteredEquipmentById(int Id)
        {
            List<RegisteredEquipment> equipment = _context.RegisteredEquipments.Where(u => u.EquipmentId == Id).ToList();
            return equipment;
        }

        public RegisteredEquipment UpdateRegisteredEquipment(RegisteredEquipment registeredEquipment, int Id)
        {
            throw new NotImplementedException();
        }
    }
}
