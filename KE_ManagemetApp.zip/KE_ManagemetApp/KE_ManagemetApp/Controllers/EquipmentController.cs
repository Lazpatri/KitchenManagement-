﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KE_ManagemetApp.Model;
using KE_ManagemetApp.Repository;

namespace KE_ManagemetApp.Controllers
{
    public class EquipmentController : IEquipment
    {
        private readonly KEMAContext _context;

        public EquipmentController(KEMAContext ctx)
        {
            _context = ctx;
        }
        public async Task<List<Equipment>> AddEquipmentAsync(List<Equipment> equipment, int Id)
        {
            _context.Equipment.AddRange(equipment);
            await _context.SaveChangesAsync();
            return equipment;
        }

        public List<Equipment> DeleteEquipmentById(int equipmentId)
        {
            List<Equipment> equip = _context.Equipment.Where(x => x.EquipmentId == equipmentId).ToList();

            _context.Equipment.RemoveRange(equip);
            _context.SaveChanges();
            return equip;
        }

        public List<Equipment> GetAllEquipment()
        {
            List<Equipment> eq = new List<Equipment>();
            eq = _context.Equipment.ToList();
            return eq;
        }

        public List<Equipment> GetEquipmentById(int Id)
        {
            List<Equipment> equipment = _context.Equipment.Where(u => u.UserId == Id).ToList();
            return equipment;
        }

        public Equipment UpdateEquipment(Equipment equip, int Id)
        {
            var _equip = _context.Equipment.First(a => a.EquipmentId == equip.EquipmentId && a.UserId == Id);
            _equip.Description = equip.Description;
            _equip.SerialNumber = equip.SerialNumber;
            _equip.Condition = equip.Condition;
            _context.SaveChanges();
            return _equip;
        }
    }
}
