﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using KE_ManagemetApp.Model;
using KE_ManagemetApp.Repository;

namespace KE_ManagemetApp.Controller
{
    public class UserController : IUser
    {
        private readonly KEMAContext _context;

        public UserController(KEMAContext ctx)
        {
            _context= ctx;
        }

        public async Task<List<User>> AddUserAsync(List<User> user)
        {
            _context.Users.AddRange(user);
            await _context.SaveChangesAsync();
            return user;
        }

        public List<User> DeleteById(int UserId)
        {

           List< User> employer = _context.Users.Where(x => x.UserId == UserId).ToList();

            _context.Users.RemoveRange(employer);
            _context.SaveChanges();
            return employer;
        }

        public  List<User> GetUserById(int UserId)
        {
            List<User> user = _context.Users.Where(u => u.UserId == UserId).ToList();
            return user;
        }

        public List<User> GetUsers()
        {
            List<User> eq = new List<User>();
            eq =  _context.Users.ToList();
            return eq;
        }

        public User UserUpdateAsync(User user)
        {
            var _user = _context.Users.First(a => a.UserId == user.UserId);
            _user.FirstName = user.FirstName;
            _user.UserName  = user.UserName;
            _user.LastName =  user.LastName;
            _user.EmailAddress = user.EmailAddress;
            _user.Password = user.Password;
            _user.UserType = user.UserType;
            _context.SaveChanges();
            return _user;
        }
    }
}
