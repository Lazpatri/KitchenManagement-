﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KE_ManagemetApp.Model;
using KE_ManagemetApp.Repository;

namespace KE_ManagemetApp.Controllers
{
    public class SiteController : ISites
    {
        private readonly KEMAContext _context;

        public SiteController(KEMAContext ctx)
        {
            _context = ctx;
        }

        public async Task<List<Site>> AddSiteAsync(List<Site> user)
        {
            _context.Sites.AddRange(user);
            await _context.SaveChangesAsync();
            return user;
        }

        public List<Site> DeleteSiteById(int SiteId)
        {

            List<Site> employer = _context.Sites.Where(x => x.SiteId == SiteId).ToList();

            _context.Sites.RemoveRange(employer);
            _context.SaveChanges();
            return employer;
        }

        public List<Site> GetSiteById(int Id)
        {
            List<Site> user = _context.Sites.Where(u => u.UserId == Id).ToList();
            return user;
        }

        public List<Site> GetAllSites()
        {
            List<Site> eq = new List<Site>();
            eq = _context.Sites.ToList();
            return eq;
        }

        public Site UpdateSite(Site site, int Id)
        {
            var _user = _context.Sites.First(a => a.SiteId == site.SiteId && a.UserId == Id);
            _user.Description = site.Description;
            _user.Active = site.Active;
           
            _context.SaveChanges();
            return _user;
        }



    }
}
