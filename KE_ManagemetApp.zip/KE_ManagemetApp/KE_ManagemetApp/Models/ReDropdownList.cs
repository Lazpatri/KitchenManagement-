﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KE_ManagemetApp.Models
{
    public class ReDropdownList
    {
        public string Condition { get; set; }
    }
}
