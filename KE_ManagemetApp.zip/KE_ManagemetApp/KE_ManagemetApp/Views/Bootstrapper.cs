using System;
using System.Collections.Generic;
using System.Reflection;
using DataAccess;
using KE_ManagemetApp.ViewModels;
using Models;
using Castle.Core;
using Castle.Facilities.TypedFactory;
using Castle.MicroKernel.Registration;
using Castle.Windsor;
using KE_ManagemetApp.MVVM;
using KE_ManagemetApp.Views.DesignTime;
using KE_ManagemetApp.Repository;
using KE_ManagemetApp.Controller;
using KE_ManagemetApp.Model;
using Microsoft.EntityFrameworkCore;
using Castle.MicroKernel.Resolvers.SpecializedResolvers;
using System.Data.Entity;
using KE_ManagemetApp.Controllers;

namespace KE_ManagemetApp.Views
{
    public class Bootstrapper : BootstrapperBase {
        private WindsorContainer container;

        protected override IEnumerable<Assembly> SelectAssemblies() {
            return new[] {typeof (MainViewModel).Assembly};
        }

        protected override void ConfigureForRuntime()
        {
            container = new WindsorContainer();
            container.Kernel.Resolver.AddSubResolver(new AppSettingsConvention());
            container.Register(
            Component.For<IRegisterEquipment>()
                            .ImplementedBy<RegisterEquipmentController>(),
            Component.For<IEquipment>()
                            .ImplementedBy<EquipmentController>(),
            Component.For<ISites>()
                            .ImplementedBy<SiteController>(),
            Component.For<IUser>()
                            .ImplementedBy<UserController>()
                            .LifeStyle.Singleton
                            .Named("KEMAContext"),
            Component.For<KEMAContext>(),
            Component.For<IEventAggregator>()
                    .ImplementedBy<EventAggregator>()
                    .LifestyleSingleton()
                );
            container.Kernel.Resolver.AddSubResolver(new CollectionResolver(container.Kernel));
            RegisterViewModels();
            container.AddFacility<TypedFactoryFacility>();

        }

        protected override void ConfigureForDesignTime()
        {
            container = new WindsorContainer();
            container.Kernel.Resolver.AddSubResolver(new AppSettingsConvention());
            container.Register(
            Component.For<IRegisterEquipment>()
                            .ImplementedBy<RegisterEquipmentController>(),
            Component.For<IEquipment>()
                            .ImplementedBy<EquipmentController>(),
            Component.For<ISites>()
                            .ImplementedBy<SiteController>(),
            Component.For<IUser>()
                            .ImplementedBy<UserController>()
                            .LifeStyle.Singleton
                            .Named("KEMAContext"),
            Component.For<KEMAContext>(),
                Component.For<IEventAggregator>()
                    .ImplementedBy<EventAggregator>()
                    .LifestyleSingleton()

                );
            RegisterViewModels();
            container.AddFacility<TypedFactoryFacility>();
        }

        protected override object GetInstance(Type service, string key) {
            return string.IsNullOrWhiteSpace(key)
                ? container.Resolve(service)
                : container.Resolve(key, service);
        }

        private void RegisterViewModels() {
            container.Register(Classes.FromAssembly(typeof(MainViewModel).Assembly)
                .Where(x => x.Name.EndsWith("ViewModel"))
                .Configure(x => x.LifeStyle.Is(LifestyleType.Transient)));
        }
    }
}