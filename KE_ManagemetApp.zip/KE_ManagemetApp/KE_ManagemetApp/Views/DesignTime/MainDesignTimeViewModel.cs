﻿using System.Collections.ObjectModel;
using Models;

namespace KE_ManagemetApp.Views.DesignTime {
    public class MainDesignTimeViewModel {
        public MainDesignTimeViewModel() {
            Students = new ObservableCollection<Student>() {
                new Student() {Age = 22, FirstName = "Wilson", LastName = "Fisk", EmailAddress = "wilson@fisk", Id = 12},
                new Student() {
                    Age = 25,
                    FirstName = "Matt",
                    LastName = "Murdock",
                    EmailAddress = "matt@murdock",
                    Id = 13
                },
            };
        }

        public ObservableCollection<Student> Students { get; set; }
    }
}