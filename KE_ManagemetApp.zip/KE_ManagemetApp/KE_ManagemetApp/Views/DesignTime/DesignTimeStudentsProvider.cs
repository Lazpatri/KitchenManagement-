﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using DataAccess;
using Models;

namespace KE_ManagemetApp.Views.DesignTime {
    public class DesignTimeStudentsProvider : IDataProvider<Student> {
        private readonly ObservableCollection<Student> students;

        public DesignTimeStudentsProvider() {
            students = new ObservableCollection<Student>() {
                new Student() {Age = 22, FirstName = "Wilson", LastName = "Fisk", EmailAddress = "wilson@fisk", Id = 12},
                new Student() {
                    Age = 25,
                    FirstName = "Matt",
                    LastName = "Murdock",
                    EmailAddress = "matt@murdock",
                    Id = 13
                },               
            };
        }

        public Student GetById(int id) {
            return students.Single(x => x.Id == id);
        }

        public void Change(Student newEntity) {
            Student toChange = GetById(newEntity.Id);
            toChange.Age = newEntity.Age;
            toChange.EmailAddress = newEntity.EmailAddress;
            toChange.FirstName = newEntity.FirstName;
            toChange.LastName = newEntity.LastName;
        }

        public void Add(Student entity) {
            students.Add(entity);
        }

        public void Remove(int id) {
            students.Remove(GetById(id));
        }

        public IEnumerable<Student> GetAll() {
            return students;
        }

        public void SubmitChanges() {}
    }
}