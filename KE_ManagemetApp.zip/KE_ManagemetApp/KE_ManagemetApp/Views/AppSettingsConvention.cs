﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Castle.Core;
using Castle.MicroKernel.Context;
using Castle.MicroKernel;
using System.Configuration;

namespace KE_ManagemetApp.Views
{
    public class AppSettingsConvention : ISubDependencyResolver
    {
        public bool CanResolve(
            CreationContext context,
            ISubDependencyResolver contextHandlerResolver,
            ComponentModel model,
            DependencyModel dependency)
        {
            return ConfigurationManager.AppSettings.AllKeys
                .Contains(dependency.DependencyKey)
                   && TypeDescriptor
                       .GetConverter(dependency.TargetType)
                       .CanConvertFrom(typeof(string));
        }

        public object Resolve(
            CreationContext context,
            ISubDependencyResolver contextHandlerResolver,
            ComponentModel model,
            DependencyModel dependency)
        {
            return TypeDescriptor
                .GetConverter(dependency.TargetType)
                .ConvertFrom(
                    ConfigurationManager.AppSettings[dependency.DependencyKey]);
        }
    }
}
