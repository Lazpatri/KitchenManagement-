﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KE_ManagemetApp.MVVM;
using System.Windows.Input;

namespace KE_ManagemetApp.ViewModels
{
    public class MaintenancePageViewModel
    {
        private readonly IEventAggregator aggregator;

        public ICommand GobackCommand { get; }
        public MaintenancePageViewModel(IEventAggregator aggregator)
        {
            this.aggregator = aggregator;
            GobackCommand = new RelayCommand(Goback);
        }

        private void Goback()
        {
            aggregator.Publish(new SwitchToVm(typeof(MainViewModel)));
        }
    }
}
