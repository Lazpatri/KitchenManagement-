﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KE_ManagemetApp.MVVM;
using System.Windows.Input;
using System.Collections.ObjectModel;
using KE_ManagemetApp.Model;
using KE_ManagemetApp.Repository;
using System.Windows;

namespace KE_ManagemetApp.ViewModels
{
    public class SignUpPageViewModel : BaseViewModel
    {

        List<User> _newuser;
        private IUser _users;

        private string _username;
        private string _password;
        private string _firstname;
        private string _lastname;
        private string _emailaddress;
        private User _selectedusertype;

        public string Username
        {
            get { return _username; }
            set
            {
                _username = value;
                OnPropertyChanged("Username");
            }
        }

        public string Password
        {
            get { return _password; }
            set
            {
                _password = value;
                OnPropertyChanged("Password");
            }
        }
        public string FirstName
        {
            get { return _firstname; }
            set
            {
                _firstname = value;
                OnPropertyChanged("FirstName");
            }
        }
        public string LastName
        {
            get { return _lastname; }
            set
            {
                _lastname = value;
                OnPropertyChanged("LastName");
            }
        }
        public string EmailAddress
        {
            get { return _emailaddress; }
            set
            {
                _emailaddress = value;
                OnPropertyChanged("EmailAddress");
            }
        }
   
      
        public User SelectedUserType
        {
            get { return _selectedusertype; }
            set
            {
                _selectedusertype = value;
                OnPropertyChanged(nameof(SelectedUserType));
            }
        }



        private readonly IEventAggregator aggregator;
        public ICommand SignUpCommand { get; }
        public ICommand GobackCommand { get; }

        public List<User> Users { get; set; }

        public SignUpPageViewModel(IUser users, IEventAggregator aggregator)
        {
            _users = users;
            this.aggregator = aggregator;
            SignUpCommand = new RelayCommand(SignUp);
            GobackCommand = new RelayCommand(Goback);
            FillDropdown();
        }

        private void Goback()
        {
            aggregator.Publish(new SwitchToVm(typeof(MainViewModel)));
        }

        private async void SignUp()
        {
            var Username = _users.GetUsers();
            var UserIfo = Username.FirstOrDefault(u => u.UserName == _username);
            if (UserIfo != null)
            {
                MessageBox.Show("UserName already taken..");
            }
            else 
            {

            _newuser = new List<User>
            {
                new User
                {
                    FirstName = _firstname,
                    LastName = _lastname,
                    EmailAddress = _emailaddress,
                    Password = _password,
                    UserName = _username,
                    UserType = _selectedusertype.UserType
                }
            };

                var Isuccess = await _users.AddUserAsync(_newuser);
                if (Isuccess != null)
                {
                    MessageBox.Show("Added Successfully!");
                    aggregator.Publish(new SwitchToVm(typeof(MainViewModel)));
                }
                else
                {
                    MessageBox.Show("Saving failed.");
                }

            }
        }


        public void FillDropdown() 
        {
            Users = new List<User>
            {
                new User
                {
                    UserType = "Admin"
                },
                    new User
                {
                    UserType = "SuperAdmin"
                }

            };
            SelectedUserType = Users[0];
        }

    }
}
