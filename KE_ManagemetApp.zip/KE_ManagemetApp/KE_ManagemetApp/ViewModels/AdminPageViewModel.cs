﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Input;
using KE_ManagemetApp.Model;
using KE_ManagemetApp.MVVM;
using KE_ManagemetApp.Repository;

namespace KE_ManagemetApp.ViewModels
{
    public class AdminPageViewModel
    {
        private IUser _users;
        private readonly IEventAggregator aggregator;
        private readonly int userID;

        List<User> usertype;

        public ICommand UserCommand { get; }
        public ICommand SiteCommand { get; }
        public ICommand EquipmentCommand { get; }
        public ICommand LogoutCommand { get; }
        public bool MyButtonIsEnabled { get; set; }
 
        public AdminPageViewModel(IUser users, IEventAggregator aggregator, int UserIDForUserType)
        {
            _users = users;
            this.aggregator = aggregator;
            userID = UserIDForUserType;

            UserCommand = new RelayCommand(GoToUser);
            SiteCommand = new RelayCommand(GoToSite);
            EquipmentCommand = new RelayCommand(GoToEquipment);
            LogoutCommand = new RelayCommand(Logout);

            usertype = _users.GetUserById(userID);
            MyButtonIsEnabled = usertype.Any(cus => cus.UserType == "SuperAdmin");
        }

        private void Logout()
        {
            aggregator.Publish(new SwitchToVm(typeof(MainViewModel)));
        }

        private void GoToEquipment()
        {
            ConfigurationManager.AppSettings.Set("CurrentUserId", userID.ToString());
            aggregator.Publish(new SwitchToVm(typeof(EquipmentMaintenancePageViewModel)));
        }

        private void GoToSite()
        {
            ConfigurationManager.AppSettings.Set("CurrentUserId", userID.ToString());
            aggregator.Publish(new SwitchToVm(typeof(SiteMaintenancePageViewModel)));
        }

        private void GoToUser()
        {
            aggregator.Publish(new SwitchToVm(typeof(UserMaintenancePageViewModel)));
        }
    }
}
