﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using KE_ManagemetApp.Model;
using KE_ManagemetApp.Models;
using KE_ManagemetApp.MVVM;
using KE_ManagemetApp.Repository;

namespace KE_ManagemetApp.ViewModels
{
    public class EquipmentMaintenancePageViewModel : BaseViewModel
    {
        private IEquipment _equipment;
        private readonly IEventAggregator aggregator;

        private string _buttonIndex;
        private string _serialnumber;
        private string _equipmentdescription;



        private Visibility _UpdatetitleText;
        private Visibility _AddtitleText;

        private readonly int userID;
        private int _equipmentid;

        public List<Equipment> AllEquipment { get; set; }
        public List<ReDropdownList> RE_DropDownText { get; set; }
        private ReDropdownList _regequipselectedstatus;
        public Equipment _listselectedequipment { get; set; }

        public ICommand AddEquipmentCommand { get; }
        public ICommand UpdateEquipmentCommand { get; }

        public ICommand SaveEquipmentCommand { get; }

        public ICommand RemoveSiteEquipmentCommand { get; }

        public ICommand GoBackCommand { get; }

        public Visibility UpdateTitleText
        {
            get { return _UpdatetitleText; }
            set
            {
                _UpdatetitleText = value;
                OnPropertyChanged("UpdateTitleText");
            }
        }
        
        public Visibility AddTitleText
        {
            get { return _AddtitleText; }
            set
            {
                _AddtitleText = value;
                OnPropertyChanged("AddTitleText");
            }
        }

        public string BtnIndex
        {
            get { return _buttonIndex; }
            set
            {
                _buttonIndex = value;
                OnPropertyChanged("BtnIndex");
            }
        }

        public string EquipmentDescription
        {
            get { return _equipmentdescription; }
            set
            {
                _equipmentdescription = value;
                OnPropertyChanged("EquipmentDescription");
            }
        }

        public string SerialNumber
        {
            get { return _serialnumber; }
            set
            {
                _serialnumber = value;
                OnPropertyChanged("SerialNumber");
            }
        }

        public Equipment ListSelectedEquipment
        {
            get => _listselectedequipment;
            set
            {
                if (_listselectedequipment == value)
                    return;

                _listselectedequipment = value;
                ListEquipmentOnSelect();
                OnPropertyChanged();
            }
        }
        public ReDropdownList ReSelectedStatus
        {
            get { return _regequipselectedstatus; }
            set
            {
                _regequipselectedstatus = value;

                OnPropertyChanged(nameof(ReSelectedStatus));
            }
        }


        public EquipmentMaintenancePageViewModel(IEventAggregator aggregator, IEquipment Iequipment, int CurrentUserId)
        {
            AddEquipmentCommand = new RelayCommand(AddEquipment);
            UpdateEquipmentCommand = new RelayCommand(UpdateEquipment);
            SaveEquipmentCommand = new RelayCommand(SaveTransaction);
            RemoveSiteEquipmentCommand = new RelayCommand(RemoveSiteEquipment);
            GoBackCommand = new RelayCommand(GoBack);

            this.aggregator = aggregator;
             _equipment= Iequipment;
            userID = CurrentUserId;
            UpdateTitleText = Visibility.Hidden;
            AddTitleText = Visibility.Hidden;
            LoadData();
            FillDropDown();

        }

        private void GoBack()
        {
            aggregator.Publish(new SwitchToVm(typeof(AdminPageViewModel)));
        }

        private void RemoveSiteEquipment()
        {
            if (_equipmentid == 0) 
            {
                MessageBox.Show("Please select an equipment");
            }
            _equipment.DeleteEquipmentById(_equipmentid);
            aggregator.Publish(new SwitchToVm(typeof(EquipmentMaintenancePageViewModel)));
        }

        private async void SaveTransaction()
        {
            if (BtnIndex == "1")
            {
                var EquipmentCheck = _equipment.GetEquipmentById(userID);
                var EquipInfo = EquipmentCheck.FirstOrDefault(u => u.Description == _equipmentdescription.Trim() && u.UserId == userID);
                if (EquipInfo != null)
                {
                    MessageBox.Show("The user has already had this type of item.");
                }
                else
                {

                    var addequip = new List<Equipment>
                    {
                        new Equipment
                        {
                            UserId = userID,
                            SerialNumber = _serialnumber,
                            Description = _equipmentdescription,
                            Condition = ReSelectedStatus.Condition
                        }
                    };

                    var Isuccess = await _equipment.AddEquipmentAsync(addequip, userID);
                    if (Isuccess != null)
                    {

                        MessageBox.Show("Added Successfully!");
                        aggregator.Publish(new SwitchToVm(typeof(EquipmentMaintenancePageViewModel)));
                    }
                    else
                    {
                        MessageBox.Show("Saving failed.");
                    }
                }
            }

            if (BtnIndex == "2")
            {
                var _modifyequip = new Equipment
                {
                    EquipmentId = _equipmentid,
                    SerialNumber = _serialnumber,
                    Condition = ReSelectedStatus.Condition,
                    Description = _equipmentdescription
                };

                var Isuccess = _equipment.UpdateEquipment(_modifyequip, userID);
                if (Isuccess != null)
                {
                    MessageBox.Show("Updated Successfully!");
                    aggregator.Publish(new SwitchToVm(typeof(EquipmentMaintenancePageViewModel)));
                }
                else
                {
                    MessageBox.Show("Saving failed.");
                }
            }
         
        }

        public void LoadData() 
        {
            AllEquipment = _equipment.GetEquipmentById(userID);
        }

        public void FillDropDown() 
        {
            RE_DropDownText = new List<ReDropdownList>
            {
                new ReDropdownList
                {
                    Condition = "Working"
                },
                new ReDropdownList
                {
                    Condition = "Not Working"
                }
            };

            ReSelectedStatus = RE_DropDownText[0];
        }

        private void AddEquipment()
        {
            _buttonIndex = "1";
            ControlVisibility();
        }

        private void UpdateEquipment()
        {
            _buttonIndex = "2";
            ControlVisibility();
        }

        public void ControlVisibility() 
        {
            AddTitleText = _buttonIndex == "1" ? Visibility.Visible : Visibility.Hidden;
            UpdateTitleText = _buttonIndex == "2" ? Visibility.Visible : Visibility.Hidden;
        }

        private void ListEquipmentOnSelect()
        {
            _equipmentid = ListSelectedEquipment.EquipmentId;
            _serialnumber = ListSelectedEquipment.SerialNumber;
            _equipmentdescription = ListSelectedEquipment.Description;
            
            if (ListSelectedEquipment.Condition == "Working")
            {
                ReSelectedStatus = RE_DropDownText[0];
            }
            else
            {
                ReSelectedStatus = RE_DropDownText[1];
            }
    
        }
    }
}
