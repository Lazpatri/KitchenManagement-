﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using DataAccess;
using KE_ManagemetApp.Model;
using KE_ManagemetApp.MVVM;
using KE_ManagemetApp.Repository;
using Models;

namespace KE_ManagemetApp.ViewModels
{
    public class MainViewModel : BaseViewModel
    {
       
        List<User> user;
        private string _username;
        private string _password;

        private IUser _users;
        private readonly IEventAggregator aggregator;

        public ICommand LoginCommand { get; }
        public ICommand SignUpCommand { get; }

        public MainViewModel(IUser users, IEventAggregator aggregator)
        {
            _users= users;
            this.aggregator = aggregator;
            LoginCommand = new RelayCommand(Login);
            SignUpCommand = new RelayCommand(SignUp);
        }

     

        public string Username
        {
            get { return _username; }
            set
            {
                _username = value;
                OnPropertyChanged("Username");
            }
        }

        public string Password
        {
            get { return _password; }
            set
            {
                _password = value;
                OnPropertyChanged("Password");
            }
        }

        private void Login()
        {
            var Username = _users.GetUsers();
            var UserIfo = Username.FirstOrDefault(u => u.UserName == _username && u.Password == _password);

            if (UserIfo != null)
            {
                ConfigurationManager.AppSettings.Set("UserIDForUserType", UserIfo.UserId.ToString());
                aggregator.Publish(new SwitchToVm(typeof(AdminPageViewModel)));
            }
            else 
            {
                MessageBox.Show("Username or Password is Incorrect, Please try again.");
            }
        }

        private void SignUp()
        {
            aggregator.Publish(new SwitchToVm(typeof(SignUpPageViewModel)));
        }
    }
}
