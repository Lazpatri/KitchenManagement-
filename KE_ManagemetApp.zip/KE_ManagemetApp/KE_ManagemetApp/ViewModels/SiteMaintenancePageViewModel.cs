﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using KE_ManagemetApp.Model;
using KE_ManagemetApp.ModelDTO;
using KE_ManagemetApp.Models;
using KE_ManagemetApp.MVVM;
using KE_ManagemetApp.Repository;

namespace KE_ManagemetApp.ViewModels
{
    public class SiteMaintenancePageViewModel : BaseViewModel
    {
        private string _formindex;
        private Visibility _form_add_site_visibility;
        private Visibility _form_edit_site_visibility;
        private Visibility _form_delete_site_visibility;
        private Visibility _formeditequipmentvisibility;
        private Visibility _btnadddeletequipment;
        private Visibility _equipmentlistview;
        private Visibility _save_equipment_btn_visible;

        private bool _sitecontrols;

        //Equipment Detail Controls
        private Visibility eq_labelvisible;
        private Visibility eq_serialnumberVisible;
        private Visibility eq_descriptionvisible;
        private Visibility eq_conditionvisible;

        public bool _equipmentcontrols_enabled;


        private string _description;
        private string _condition;
        private string _serialnumber;
        private string _equipmentdescription;
        private int _siteid;
        private int _equipmentid;

        public bool _form_add_site_enabled;
        public bool _form_edit_site_enabled;
        public bool _form_delete_site_enabled;
        public bool _formeditequipmentenabled;
        public bool _register_delete_enabled;



        private DropdownList _selectedstatus;
        private ReDropdownList _regequipselectedstatus;
        private readonly int userID;

        public Site _selectedsite { get; set; }
        public SiteDTO _listselectedsite { get; set; }

        public Equipment _listselectedequipment { get; set; }

        private readonly IEventAggregator aggregator;
        private ISites _sites;
        private IEquipment _equipment;
        private IRegisterEquipment _registeredequipment;


        public List<Site> DropDownSite { get; set; }
        public List<Site> AllSites { get; set; }
        public List<Equipment> AllEquipment { get; set; }
        public List<SiteDTO> SitesDto { get; set; }

        public List<DropdownList> DropDownSiteText { get; set; }
        public List<ReDropdownList> RE_DropDownText { get; set; }


        public ICommand AddSiteCommand { get; }
        public ICommand UpdateSiteCommand { get; }
        public ICommand DeleteSiteCommand { get; }

        public ICommand EditSiteEquipment { get; }

        public ICommand InsertSiteCommand { get; }

        public ICommand EditSiteCommand { get; }

        public ICommand RemoveSiteCommand { get; }

        public ICommand AddSiteEquipmentCommand { get; }

        public ICommand RemoveSiteEquipmentCommand { get; }

        public ICommand RegisterEquipmentCommand { get; }

        public ICommand SaveEquipmentCommand { get; }

        public ICommand GoBackCommand { get; }



        public bool SiteControlEnabled
        {
            get { return _sitecontrols; }
            set
            {
                _sitecontrols = value;
                OnPropertyChanged("SiteControlEnabled");
            }
        }

        public bool EquipmentControlEnabled
        {
            get { return _equipmentcontrols_enabled; }
            set
            {
                _equipmentcontrols_enabled = value;
                OnPropertyChanged("EquipmentControlEnabled");
            }
        }

        public bool Regiter_Delete_Enabled
        {
            get { return _register_delete_enabled; }
            set
            {
                _register_delete_enabled = value;
                OnPropertyChanged("Regiter_Delete_Enabled");
            }
        }

        public Visibility SaveEquipmentBtnVisible
        {
            get { return _save_equipment_btn_visible; }
            set
            {
                _save_equipment_btn_visible = value;
                OnPropertyChanged("SaveEquipmentBtnVisible");
            }
        }


        public Visibility FormEditEquipmentEnabled
        {
            get { return _formeditequipmentvisibility; }
            set
            {
                _formeditequipmentvisibility = value;
                OnPropertyChanged("FormEditEquipmentEnabled");
            }
        }
        public Visibility FormAddSiteEnabled
        {
            get { return _form_add_site_visibility; }
            set
            {
                _form_add_site_visibility = value;
                OnPropertyChanged("FormAddSiteEnabled");
            }
        }
        public Visibility FormEditSiteEnabled
        {
            get { return _form_edit_site_visibility; }
            set
            {
                _form_edit_site_visibility = value;
                OnPropertyChanged("FormEditSiteEnabled");
            }
        }
        public Visibility FormDeleteSiteEnabled
        {
            get { return _form_delete_site_visibility; }
            set
            {
                _form_delete_site_visibility = value;
                OnPropertyChanged("FormDeleteSiteEnabled");
            }
        }
        public Visibility BtnAddDeleteEquipment
        {
            get { return _btnadddeletequipment; }
            set
            {
                _btnadddeletequipment = value;
                OnPropertyChanged("BtnAddDeleteEquipment");
            }
        }

        public Visibility EquipmentListviewVisible
        {
            get { return _equipmentlistview; }
            set
            {
                _equipmentlistview = value;
                OnPropertyChanged("EquipmentListviewVisible");
            }
        }
        public Visibility Eq_LabelVisible
        {
            get { return eq_labelvisible; }
            set
            {
                eq_labelvisible = value;
                OnPropertyChanged("Eq_LabelVisible");
            }
        }
        public Visibility Eq_SerialNumberVisible
        {
            get { return eq_serialnumberVisible; }
            set
            {
                eq_serialnumberVisible = value;
                OnPropertyChanged("Eq_SerialNumberVisible");
            }
        }
        public Visibility Eq_DescriptionVisible
        {
            get { return eq_descriptionvisible; }
            set
            {
                eq_descriptionvisible = value;
                OnPropertyChanged("Eq_DescriptionVisible");
            }
        }
        public Visibility Eq_ConditionVisible
        {
            get { return eq_conditionvisible; }
            set
            {
                eq_conditionvisible = value;
                OnPropertyChanged("Eq_ConditionVisible");
            }
        }


        public string FormIndex
        {
            get { return _formindex; }
            set
            {
                _formindex = value;
                OnPropertyChanged("FormIndex");
            }
        }

        public DropdownList SelectedStatus
        {
            get { return _selectedstatus; }
            set
            {
                _selectedstatus = value;
                OnPropertyChanged(nameof(SelectedStatus));
            }
        }

        public ReDropdownList ReSelectedStatus
        {
            get { return _regequipselectedstatus; }
            set
            {
                _regequipselectedstatus = value;

                OnPropertyChanged(nameof(ReSelectedStatus));
            }
        }

        public string Description
        {
            get { return _description; }
            set
            {
                _description = value;
                OnPropertyChanged("Description");
            }
        }

        public string EquipmentDescription
        {
            get { return _equipmentdescription; }
            set
            {
                _equipmentdescription = value;
                OnPropertyChanged("EquipmentDescription");
            }
        }

        public string SerialNumber
        {
            get { return _serialnumber; }
            set
            {
                _serialnumber = value;
                OnPropertyChanged("SerialNumber");
            }
        }

        public string Condition
        {
            get { return _condition; }
            set
            {
                _condition = value;
                OnPropertyChanged("Condition");
            }
        }

        public SiteDTO ListSelectedSite
        {
            get => _listselectedsite;
            set
            {
                if (_listselectedsite == value)
                    return;

                _listselectedsite = value;
                ListSiteOnSelect();
                OnPropertyChanged();
            }
        }

        public Equipment ListSelectedEquipment
        {
            get => _listselectedequipment;
            set
            {
                if (_listselectedequipment == value)
                    return;

                _listselectedequipment = value;
                ListEquipmentOnSelect();
                OnPropertyChanged();
            }
        }


        public Site SelectedSite
        {
            get => _selectedsite;
            set
            {
                if (_selectedsite == value)
                    return;

                _selectedsite = value;
                OnPropertyChanged();
            }
        }

        public SiteMaintenancePageViewModel(IEventAggregator aggregator, ISites Isites, IEquipment Iequipment, IRegisterEquipment Iregequip, int CurrentUserId)
        {
            _sites = Isites;
            _equipment = Iequipment;
            _registeredequipment = Iregequip;
            this.aggregator = aggregator;
            userID = CurrentUserId;

            AddSiteCommand = new RelayCommand(AddSite);
            UpdateSiteCommand = new RelayCommand(UpdateSite);
            DeleteSiteCommand = new RelayCommand(DeleteSite);
            EditSiteEquipment = new RelayCommand(EditSiteEquip);
            InsertSiteCommand = new RelayCommand(InsertSite);
            EditSiteCommand = new RelayCommand(EditSite);
            RemoveSiteCommand = new RelayCommand(RemoveSite);
            AddSiteEquipmentCommand = new RelayCommand(AddSiteEquipment);
            RemoveSiteEquipmentCommand = new RelayCommand(RemoveSiteEquipment);
            RegisterEquipmentCommand = new RelayCommand(RegisterEquipment);
            SaveEquipmentCommand = new RelayCommand(SaveEquipment);
            GoBackCommand = new RelayCommand(GoBack);

            FillDropdown();
            ReloadData();
        }

        private void GoBack()
        {
            aggregator.Publish(new SwitchToVm(typeof(AdminPageViewModel)));
        }

        private async void SaveEquipment()
        {
            var EquipmentCheck =  _equipment.GetEquipmentById(userID);
            var EquipInfo = EquipmentCheck.FirstOrDefault(u => u.Description == _description && u.UserId == userID);
            if (EquipInfo != null)
            {
                MessageBox.Show("The user has already had this type of item.");
            }
            else 
            {
                var addequip = new List<Equipment>
                {
                    new Equipment
                    {
                        UserId = userID,
                        SerialNumber = _serialnumber,
                        Description = _equipmentdescription,
                        Condition = ReSelectedStatus.Condition
                    }
                };

                var Isuccess = await _equipment.AddEquipmentAsync(addequip, userID);
                if (Isuccess != null)
                {

                    MessageBox.Show("Equipment was added successfully!");
                    aggregator.Publish(new SwitchToVm(typeof(SiteMaintenancePageViewModel)));
                }
                else
                {
                    MessageBox.Show("Failed saving data.");
                }
            }     
        }

        private async void RegisterEquipment()
        {
            var Registered_eq = _registeredequipment.GetRegisteredEquipmentById(_equipmentid);
            var check_RE = Registered_eq.FirstOrDefault(u => u.EquipmentId == _equipmentid);


            if (check_RE != null)
            {
                MessageBox.Show("This equipment is already registered to a site.");
            }
            else 
            {
                var register_equipment = new List<RegisteredEquipment>
                {
                    new RegisteredEquipment
                    {
                        SiteId = _siteid,
                        EquipmentId = _equipmentid
                    }
                };

                var Isuccess = await _registeredequipment.AddRegisteredEquipmentAsync(register_equipment);
                if (Isuccess != null) 
                {
                    MessageBox.Show("Registered successfuly!");
                }
            }      
        }

        private async void AddSiteEquipment()
        {
            EquipmentControlEnabled = true;
            SerialNumber = "";
            EquipmentDescription = "";
            ReSelectedStatus = RE_DropDownText[0];
            SaveEquipmentBtnVisible = Visibility.Visible;
            Regiter_Delete_Enabled = false;
        }

        private void RemoveSiteEquipment()
        {
            _equipment.DeleteEquipmentById(_equipmentid);
            aggregator.Publish(new SwitchToVm(typeof(SiteMaintenancePageViewModel)));
        }

        private void RemoveSite()
        {
            _sites.DeleteSiteById(_siteid);
            _registeredequipment.DeleteRegisteredEquipmentById(_siteid);
            MessageBox.Show("Items Deleted successfully.");
            aggregator.Publish(new SwitchToVm(typeof(SiteMaintenancePageViewModel)));
        }

        private void EditSite()
        {
            var _modifysite = new Site
            {
                SiteId = _siteid,
                Description = _description,
                Active = SelectedStatus.Status == "Active" ? true : false
            };

            var Isuccess = _sites.UpdateSite(_modifysite, userID);
            if (Isuccess != null)
            {
                MessageBox.Show("Updated Successfully!");
                aggregator.Publish(new SwitchToVm(typeof(SiteMaintenancePageViewModel)));
            }
            else
            {
                MessageBox.Show("Saving failed.");
            }
        }

        private async void InsertSite()
        {
            var Site = _sites.GetAllSites();
            var SiteInfo = Site.FirstOrDefault(u => u.Description == _description);
            if (SiteInfo != null)
            {
                MessageBox.Show("Site Already exist..");
            }
            else
            {
                var _site = new List<Site>
                {
                    new Site
                    {
                        UserId = userID,
                        Description = _description,
                        Active = SelectedStatus.Status == "Active" ? true : false
                    }
                };

                var Isuccess = await _sites.AddSiteAsync(_site);
                if (Isuccess != null)
                {
                    MessageBox.Show("Site has been added Successfully!");
                    aggregator.Publish(new SwitchToVm(typeof(SiteMaintenancePageViewModel)));
                }
                else
                {
                    MessageBox.Show("Failed to save data.");
                }
            }
        }

        public void ReloadData()
        {
            AllSites = _sites.GetSiteById(userID);
            AllEquipment = _equipment.GetEquipmentById(userID);
            List<SiteDTO> _SitesDto = new List<SiteDTO>();
            foreach (var rp in AllSites)
            {
                _SitesDto.Add(new SiteDTO() { SiteId = rp.SiteId, UserId = rp.UserId, Description = rp.Description, Status = rp.Active == true ? "Active" : "InActive" });
            }
            SitesDto = _SitesDto;

            FormAddSiteEnabled = Visibility.Visible;
            FormEditSiteEnabled = Visibility.Hidden;
            FormDeleteSiteEnabled = Visibility.Hidden;
            FormEditEquipmentEnabled = Visibility.Hidden;
            BtnAddDeleteEquipment = Visibility.Hidden;
            EquipmentListviewVisible = Visibility.Hidden;

            Eq_LabelVisible = Visibility.Hidden;
            Eq_SerialNumberVisible = Visibility.Hidden;
            Eq_DescriptionVisible = Visibility.Hidden;
            Eq_ConditionVisible = Visibility.Hidden;
            SaveEquipmentBtnVisible = Visibility.Hidden;

        }



        public void FormVisibility()
        {
            FormEditEquipmentEnabled = _formindex == "4" ? Visibility.Visible : Visibility.Hidden;
            FormDeleteSiteEnabled = _formindex == "3" ? Visibility.Visible : Visibility.Hidden;
            FormEditSiteEnabled = _formindex == "2" ? Visibility.Visible : Visibility.Hidden;
            FormAddSiteEnabled = _formindex == "1" ? Visibility.Visible : Visibility.Hidden;

            Eq_LabelVisible = _formindex == "4" ? Visibility.Visible : Visibility.Hidden;
            Eq_SerialNumberVisible = _formindex == "4" ? Visibility.Visible : Visibility.Hidden;
            Eq_DescriptionVisible = _formindex == "4" ? Visibility.Visible : Visibility.Hidden;
            Eq_ConditionVisible = _formindex == "4" ? Visibility.Visible : Visibility.Hidden;
            BtnAddDeleteEquipment = _formindex == "4" ? Visibility.Visible : Visibility.Hidden;
            EquipmentListviewVisible = _formindex == "4" ? Visibility.Visible : Visibility.Hidden;
            SaveEquipmentBtnVisible = _formindex == "4" ? Visibility.Visible : Visibility.Hidden;
            SiteControlEnabled = _formindex == "4" ? false : true;
          



            _form_add_site_enabled = _formindex == "1" ? true : false;
            _form_edit_site_enabled = _formindex == "2" ? true : false;
            _form_delete_site_enabled = _formindex == "3" ? true : false;
            _formeditequipmentenabled = _formindex == "4" ? true : false;
        }


        private async void AddSite()
        {
            _formindex = "1";
            FormVisibility();      

        }

    
        private void UpdateSite()
        {
            _formindex = "2";
            FormVisibility();

        }
        private void DeleteSite()
        {
            _formindex = "3";    
            FormVisibility();
            SiteControlEnabled = false;

        }

        private void EditSiteEquip()
        {
            _formindex = "4";
            FormVisibility();
        }

        public void FillDropdown()
        {
    
            DropDownSiteText = new List<DropdownList>
            {
                new DropdownList
                {
                    Status = "Active"
                },
                new DropdownList
                {
                    Status = "InActive"
                }

            };

            RE_DropDownText = new List<ReDropdownList>
            {
                new ReDropdownList
                {
                    Condition = "Working"
                },
                new ReDropdownList
                {
                    Condition = "Not Working"
                }
            };

            SelectedStatus = DropDownSiteText[0];
            ReSelectedStatus = RE_DropDownText[0];
        }

        private void ListSiteOnSelect()
        {
            _siteid = ListSelectedSite.SiteId;
            _description = ListSelectedSite.Description;
            if (ListSelectedSite.Status == "Active")
            {
                SelectedStatus = DropDownSiteText[0];
            }
            else
            {
                SelectedStatus = DropDownSiteText[1];
            }
         
        }

        private void ListEquipmentOnSelect() 
        {
            _equipmentid = ListSelectedEquipment.EquipmentId;
            _serialnumber = ListSelectedEquipment.SerialNumber;
            _equipmentdescription = ListSelectedEquipment.Description;
            if (ListSelectedEquipment.Condition == "Working") 
            {
                ReSelectedStatus = RE_DropDownText[0];
            }
            else
            {
                ReSelectedStatus = RE_DropDownText[1];
            }
            EquipmentControlEnabled = false;
            SaveEquipmentBtnVisible = Visibility.Hidden;
            Regiter_Delete_Enabled = true;
        }

    }
}
