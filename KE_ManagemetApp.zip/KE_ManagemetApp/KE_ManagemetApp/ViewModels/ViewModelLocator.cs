﻿using KE_ManagemetApp.MVVM;


namespace KE_ManagemetApp.ViewModels {
    public class ViewModelLocator {
        public MainViewModel MainViewModel {
            get { return IoC.Get<MainViewModel>(); }
        }
    }
}