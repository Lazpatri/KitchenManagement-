﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using KE_ManagemetApp.Model;
using KE_ManagemetApp.MVVM;
using KE_ManagemetApp.Repository;

namespace KE_ManagemetApp.ViewModels
{
    public class UserMaintenancePageViewModel : BaseViewModel
    {

        List<User> _newuser;
        private string _username;
        private string _password;
        private string _firstname;
        private string _lastname;
        private string _emailaddress;
        private int _userid;
        private User _selectedusertype;
        private IUser _users;
        private readonly IEventAggregator aggregator;

        public List<User> Users { get; set; }
        public List<User> UsersDropDown { get; set; }


        private int _selectedIndex;
        public User _SelectedUser { get; set; }

        public ICommand UpdateUserCommand { get; }
        public ICommand DeleteUserCommand { get; }
        public ICommand GoBackUserCommand { get; }

        public User SelectedUser
        {
            get => _SelectedUser;
            set
            {
                if (_SelectedUser == value)
                    return;

                _SelectedUser = value;
                OnSelect();
                OnPropertyChanged();
            }
        }

        public string UsernameTxt
        {
            get { return _username; }
            set
            {
                _username = value;
                OnPropertyChanged("UsernameTxt");
            }
        }

        public string PasswordTxt
        {
            get { return _password; }
            set
            {
                _password = value;
                OnPropertyChanged("PasswordTxt");
            }
        }
        public string FirstNameTxt
        {
            get { return _firstname; }
            set
            {
                _firstname = value;
                OnPropertyChanged("FirstNameTxt");
            }
        }
        public string LastNameTxt
        {
            get { return _lastname; }
            set
            {
                _lastname = value;
                OnPropertyChanged("LastNameTxt");
            }
        }
        public string EmailAddressTxt
        {
            get { return _emailaddress; }
            set
            {
                _emailaddress = value;
                OnPropertyChanged("EmailAddressTxt");
            }
        }


        public User SelectedUserType
        {
            get { return _selectedusertype; }
            set
            {
                _selectedusertype = value;
                OnPropertyChanged(nameof(SelectedUserType));
            }
        }


        public UserMaintenancePageViewModel(IUser users, IEventAggregator aggregator)
        {
            _users = users;
            this.aggregator = aggregator;

            UpdateUserCommand = new RelayCommand(UpdateUser);
            DeleteUserCommand = new RelayCommand(DeleteUser);
            GoBackUserCommand = new RelayCommand(GoBack);


            ReloadUsers();
            FillDropdown();
         
        }

        private void GoBack()
        {
            aggregator.Publish(new SwitchToVm(typeof(AdminPageViewModel)));
        }

        public void ReloadUsers() 
        {
            Users = _users.GetUsers();
        }

        private void UpdateUser()
        {
            var _newuser = new User
            {
                    UserId = _userid,
                    FirstName = _firstname,
                    LastName = _lastname,
                    EmailAddress = _emailaddress,
                    Password = _password,
                    UserName = _username,
                    UserType = _selectedusertype.UserType              
            };

            var Isuccess =  _users.UserUpdateAsync(_newuser);
            if (Isuccess != null)
            {
                MessageBox.Show("Updated Successfully!");
                aggregator.Publish(new SwitchToVm(typeof(UserMaintenancePageViewModel)));
            }
            else
            {
                MessageBox.Show("Saving failed.");
            }
        }

        private void DeleteUser()
        {
            _users.DeleteById(SelectedUser.UserId);
            aggregator.Publish(new SwitchToVm(typeof(UserMaintenancePageViewModel)));
        }

        public void FillDropdown()
        {
           
            UsersDropDown = new List<User>
            {
                new User
                {
                    UserType = "Admin"
                },
                    new User
                {
                    UserType = "SuperAdmin"
                }
            };
            SelectedUserType = UsersDropDown[0];
        }

        private void OnSelect() 
        {
            _userid = SelectedUser.UserId;
            _firstname = SelectedUser.FirstName;
            _lastname = SelectedUser.LastName;
            _emailaddress = SelectedUser.EmailAddress;
            _username = SelectedUser.UserName;
            _password = SelectedUser.Password;
            if (SelectedUser.UserType == "SuperAdmin")
            {
                SelectedUserType = UsersDropDown[1];
            }
            else 
            {
                SelectedUserType = UsersDropDown[0];
            }
        }


    }
}
