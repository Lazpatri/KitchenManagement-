﻿using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using KE_ManagemetApp.Model;
using Models;

namespace DataAccess {
    public class StudentsXmlProvider : IDataProvider<User> {

        private readonly KEMAContext _context;
        public StudentsXmlProvider(KEMAContext ctx)
        {
            _context = ctx;
        }
        public void Change(User newEntity)
        {
            throw new System.NotImplementedException();
        }

        public void Add(User entity)
        {
            throw new System.NotImplementedException();
        }

        IEnumerable<User> IDataProvider<User>.GetAll()
        {
            throw new System.NotImplementedException();
        }


    }
}